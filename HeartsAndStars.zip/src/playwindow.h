#ifndef PLAYWINDOW_H
#define PLAYWINDOW_H

#include <QMainWindow>
#include <QObject>
#include <QWidget>

class PlayWindow
{
public:
    PlayWindow();
};

#endif // PLAYWINDOW_H
